﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace MTE
{
    #if UNITY_EDITOR
    //Please keep this attribute, it is used by MTE editor.
    [ExecuteInEditMode]
    #endif
    public class GrassLoader : MonoBehaviour
    {
        public GrassList grassInstanceList = null;

        void Start()
        {
            this.RemoveOldGrasses();
            this.GenerateGrasses();
        }

        /// <summary>
        /// Remove all grass objects under this GameObject
        /// </summary>
        /// <remarks>
        /// Please keep this method public, because MTE Editor will call this method.
        /// </remarks>
        public void RemoveOldGrasses()
        {
            bool isEditor = Application.isEditor;

            // remove child GameObjects
            for (var i = this.transform.childCount - 1; i >= 0; i--)
            {
                var objTransform = this.transform.GetChild(i);
                if (isEditor)
                {
                    DestroyImmediate(objTransform.gameObject);
                }
                else
                {
                    Destroy(objTransform.gameObject);
                }
            }
        }

        /// <summary>
        /// Generate grass instances in the scene
        /// </summary>
        /// <param name="callback">(Used by MTE Editor)</param>
        /// <remarks>
        /// Please keep this method public, because MTE will call this method to generate grasses in editor.
        /// </remarks>
        public void GenerateGrasses(System.Action<object, GameObject> callback = null)
        {
            if (grassInstanceList == null) return;

            bool isEditor = Application.isEditor;

            // generate new grass GameObjects as children
            // three-quads
            List<GrassStar> instances = grassInstanceList.grasses;
            if (instances != null && instances.Count != 0)
            {
                for (int i = 0; i < instances.Count; i++)
                {
                    var grass = instances[i];
                    var grassObject = GrassUtil.GenerateGrassInstance(
                        grass.Position,
                        Quaternion.Euler(0, grass.RotationY, 0),
                        grass.Width, grass.Height,
                        grass.Material);
                    if(isEditor)
                    {
                        grassObject.hideFlags = HideFlags.HideAndDontSave;
                    }
                    grassObject.transform.SetParent(this.transform, true);
                    if (callback != null)
                    {
                        callback(grass, grassObject);
                    }
                }

                StaticBatchingUtility.Combine(this.gameObject);
            }

            // quads
            List<GrassQuad> quads = grassInstanceList.quads;
            if (quads != null && quads.Count != 0)
            {
                for (int i = 0; i < quads.Count; i++)
                {
                    var grass = quads[i];
                    var grassObject = GrassUtil.GenerateGrassQuad(
                        grass.Position,
                        grass.Width, grass.Height,
                        grass.Material);
                    if (isEditor)
                    {
                        grassObject.hideFlags = HideFlags.HideAndDontSave;
                    }
                    grassObject.transform.SetParent(this.transform, true);
                    if (callback != null)
                    {
                        callback(quads, grassObject);
                    }
                }

                // billboards shouldn't be static-batched
            }

        }
    }

}
