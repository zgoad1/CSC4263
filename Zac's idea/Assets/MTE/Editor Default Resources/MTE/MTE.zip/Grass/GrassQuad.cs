﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace MTE
{
    [Serializable]
    public class GrassQuad
    {
        [SerializeField]
        private Material material;
        [SerializeField]
        private Vector3 position;
        [SerializeField]
        private float width;
        [SerializeField]
        private float height;

        public Material Material
        {
            get { return material; }
        }

        public Vector3 Position
        {
            get { return position; }
        }

        public float Width
        {
            get { return width; }
        }

        public float Height
        {
            get { return height; }
        }

        public void Init(Material material, Vector3 position, float width, float height)
        {
            this.material = material;
            this.position = position;
            this.width = width;
            this.height = height;
        }
    }
}
