﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace MTE
{
    [Serializable]
    public class GrassStar
    {
        [SerializeField]
        private Material material;
        [SerializeField]
        private Vector3 position;
        [SerializeField]
        private float rotationY;
        [SerializeField]
        private float width;
        [SerializeField]
        private float height;

        public Material Material
        {
            get { return material; }
        }

        public Vector3 Position
        {
            get { return position; }
        }

        public float RotationY
        {
            get { return rotationY; }
        }

        public float Width
        {
            get { return width; }
        }

        public float Height
        {
            get { return height; }
        }

        /// <param name="position">position in world space</param>
        /// <param name="rotationY">rotation Y (Euler angles Y)</param>
        /// <param name="width">width of a quad</param>
        /// <param name="height">height of a quad</param>
        public void Init(Material material, Vector3 position, float rotationY, float width, float height)
        {
            this.material = material;
            this.position = position;
            this.rotationY = rotationY;
            this.width = width;
            this.height = height;
        }
    }
}
